
//used to perform user logout operation
const AdminLogOut = () => {

    //navigating to another page using history.push()
    window.location.href = '/';

   
}
//exporting UserLogout
export default AdminLogOut;
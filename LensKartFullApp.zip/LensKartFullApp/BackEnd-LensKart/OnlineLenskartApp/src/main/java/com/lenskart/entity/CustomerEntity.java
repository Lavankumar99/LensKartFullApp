package com.lenskart.entity;


import javax.persistence.Entity;



@Entity
public class CustomerEntity extends UserEntity{


}

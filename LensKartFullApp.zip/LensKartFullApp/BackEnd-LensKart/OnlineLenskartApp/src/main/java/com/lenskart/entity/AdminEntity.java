package com.lenskart.entity;

import javax.persistence.Entity;

@Entity


public class AdminEntity extends UserEntity{
	
	
	
	

}

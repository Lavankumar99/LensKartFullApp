package com.lenskart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineLenskartAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
